if(cfg.integrationLicense=="Enterprise Edition"){
    return "Quantity cannot be less than 1";
}

return "Quantity cannot be less than 2";