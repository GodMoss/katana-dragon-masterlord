ProductList.uniqueIdentifier="parent";
ProductList.id = "parent";
ProductList.qty = 1;
ProductList.next();
ProductList.parentProduct = "parent";
ProductList.id = "child";
ProductList.uniqueIdentifier = "child";
ProductList.qty=1;
ProductList.next();

return ProductList;