ProductList.extended = {"cost": 62, "margin": 4, "customText":"Example 2"};
let test =  JSON.parse(ProductList.extended).cost;

ProductList.bomType = "Manufacturing";
ProductList.id = "D123";
ProductList.description = "Ring";
ProductList.qty = 1;
ProductList.uom = "EA (Each)";

ProductList.next();

ProductList.bomType = "Manufacturing";
ProductList.id = "D456";
ProductList.description = "Seal";
ProductList.qty = 1;
ProductList.uom = "EA (Each)";


return ProductList;