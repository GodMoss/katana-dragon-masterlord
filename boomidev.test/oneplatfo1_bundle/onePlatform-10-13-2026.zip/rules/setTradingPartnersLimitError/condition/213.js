if((cfg.tradingPartnersTestConnection+cfg.tradingPartnersProductionConnection)>cfg.tradingPartnerPool && (cfg.editions=="Base"|| cfg.editions=="Digital")){
    return true;
}
return false;