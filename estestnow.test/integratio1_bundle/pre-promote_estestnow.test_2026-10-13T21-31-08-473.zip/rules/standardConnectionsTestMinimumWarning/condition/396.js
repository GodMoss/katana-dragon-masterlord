var mapping={"Pro Edition - 2 Connections":2,"Pro Edition - 3 Connections":3,"Pro Edition - 4 Connections":4,"Professional Edition":5,"Pro Plus Edition":7,"Enterprise Edition":20,"Enterprise Plus Edition":30};

if(cfg.standardTestConnection<mapping[cfg.integrationLicense]){
    return true;
};

return false;