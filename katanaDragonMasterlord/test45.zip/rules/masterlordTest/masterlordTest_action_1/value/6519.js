var masterlord=lookup("Select Dragon From Masterlord");
return "";