if(cfg.integrationLicense=="Pro Plus Edition"){
    return "Quantity cannot be less than 1";
}
return "Quantity cannot be less than 2";