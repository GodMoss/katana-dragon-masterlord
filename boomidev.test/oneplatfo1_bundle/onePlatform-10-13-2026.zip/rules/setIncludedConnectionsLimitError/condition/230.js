if((cfg.standardProductionConnection+cfg.enterpriseProductionConnection+cfg.standardTestConnection+cfg.enterpriseTestConnection)>cfg.connectionsPool){
    return true;
}
return false;