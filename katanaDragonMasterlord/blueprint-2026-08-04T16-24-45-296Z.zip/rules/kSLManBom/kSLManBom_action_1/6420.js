    ProductList.id = "109258";
    ProductList.bomType = "MBOM";
    ProductList.notes = "WIRE,6J22 STRANDED UNSHIELDED";
    ProductList.price = .17;
    ProductList.quantity = 35 * 100;
    ProductList.orderNumber = 1;
    ProductList.next();

    ProductList.id = "111265";
    ProductList.bomType = "MBOM";
    ProductList.notes = "STANCION GARAGE PS-042";
    ProductList.price = 145;
    ProductList.quantity = 2;
    ProductList.orderNumber = 2;
    ProductList.next();

    ProductList.id = "160044";
    ProductList.bomType = "MBOM";
    ProductList.notes = "CONTACT 189-12WG 1'' BROWN 4.70 OHM EOL RESISTOR";
    ProductList.price = 9.57;
    ProductList.quantity = 45;
    ProductList.orderNumber = 3;
    ProductList.next();

    ProductList.id = "141151";
    ProductList.bomType = "MBOM";
    ProductList.notes = "SWITCH,HOLD UP BUTTON HUB-T 2 BUTTONS";
    ProductList.price = 25.46 ;
    ProductList.quantity = 1;
    ProductList.orderNumber = 4;
    ProductList.next();

    ProductList.id = "201405";
    ProductList.bomType = "MBOM";
    ProductList.notes = "Bosch DS9360 Ceiling Mount PIR/Microwave 360 Deg. Motion UL";
    ProductList.price = 118.54;
    ProductList.quantity = 30;
    ProductList.orderNumber = 5;
    ProductList.next();

    ProductList.id = "201381";
    ProductList.bomType = "MBOM";
    ProductList.notes = "Kastle Hub Enclosure Complete";
    ProductList.price = 368.80;
    ProductList.quantity = 10;
    ProductList.orderNumber = 6;
    ProductList.next();

    ProductList.id = "201887";
    ProductList.bomType = "MBOM";
    ProductList.notes = "KR-100 Mullion Mount";
    ProductList.price = 146.45;
    ProductList.quantity = 3;
    ProductList.orderNumber = 7;
    ProductList.next();

    ProductList.id = "201488";
    ProductList.bomType = "MBOM";
    ProductList.notes = "Ubiquiti ES-8-150W. Mng PoE+ Gig Switch. 2 SFP, Edge Switch 8";
    ProductList.price = 253.36;
    ProductList.quantity = 2;
    ProductList.orderNumber = 8;
    ProductList.next();

    ProductList.id = "126144";
    ProductList.bomType = "MBOM";
    ProductList.notes = "EXIT BUTTON, KK-3, 2G,SS, WM, PANIC";
    ProductList.price = 69.41;
    ProductList.quantity = 5;
    ProductList.orderNumber = 9;
    ProductList.next();

    ProductList.id = "129918";
    ProductList.bomType = "MBOM";
    ProductList.notes = "PLYWOOD 24X24 FIRE RATED 3/4INCH";
    ProductList.price = 20.69;
    ProductList.quantity = 5;
    ProductList.orderNumber = 10;
    ProductList.next();

return ProductList;