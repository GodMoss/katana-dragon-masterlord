if (cfg.editions == "Digital"){
    return 12;
}
if (cfg.editions == "Base"){
    return 20;
}
if (cfg.editions == "Professional"){
    return 50;
}
if (cfg.editions == "Enterprise"){
    return 250;
}
if (cfg.editions == "Enterprise Plus"){
    return 10000;
}
return 0;