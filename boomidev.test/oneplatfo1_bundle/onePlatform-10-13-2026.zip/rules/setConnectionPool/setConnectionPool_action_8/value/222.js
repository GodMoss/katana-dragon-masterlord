if (cfg.editions == "Digital"){
    return 125;
}
if (cfg.editions == "Base"){
    return 250;
}
if (cfg.editions == "Professional"){
    return 9999;
}
if (cfg.editions == "Enterprise"){
    return 9999;
}
if (cfg.editions == "Enterprise Plus"){
    return 9999;
}
return 0;