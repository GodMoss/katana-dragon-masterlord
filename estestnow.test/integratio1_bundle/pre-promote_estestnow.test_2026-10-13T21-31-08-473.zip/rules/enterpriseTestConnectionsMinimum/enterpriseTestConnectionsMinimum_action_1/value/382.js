if(cfg.integrationLicense=="Enterprise Edition"){
    return 2;
}

return 4;