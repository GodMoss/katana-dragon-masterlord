ProductList.id="ABC00001";
ProductList.bomType="SALES";
ProductList.description="fender strat accessory #1";
ProductList.price=2699.00;
ProductList.qty=1;
ProductList.next();

ProductList.id="ABC00002";
ProductList.bomType="SALES";
ProductList.description="test with longer description that will wrap";
ProductList.price=19.99;
ProductList.qty=99;
ProductList.next();

ProductList.id="ABC00003";
ProductList.bomType="SALES";
ProductList.description="test with longer description that will wrap";
ProductList.price=19.99;
ProductList.qty=2;
ProductList.next();

ProductList.id="ABC00004";
ProductList.bomType="SALES";
ProductList.description="test with longer description that will wrap";
ProductList.price=19.99;
ProductList.qty=2;
ProductList.next();

ProductList.id="ABC00005";
ProductList.bomType="SALES";
ProductList.description="test with longer description that will wrap";
ProductList.price=19.99;
ProductList.qty=99;
ProductList.next();

ProductList.id="ABC00006";
ProductList.bomType="SALES";
ProductList.description="test with longer description that will wrap";
ProductList.price=19.99;
ProductList.qty=2;
ProductList.next();

ProductList.id="ABC00007";
ProductList.bomType="SALES";
ProductList.description="test with longer description that will wrap";
ProductList.price=19.99;
ProductList.qty=2;
ProductList.next();

ProductList.id="ABC00008";
ProductList.bomType="SALES";
ProductList.description="test with longer description that will wrap";
ProductList.price=19.99;
ProductList.qty=2;
ProductList.next();

ProductList.id="ABC00009";
ProductList.bomType="SALES";
ProductList.description="test with longer description that will wrap";
ProductList.price=19.99;
ProductList.qty=2;
ProductList.next();

ProductList.id="ABC00010";
ProductList.bomType="SALES";
ProductList.description="test with longer description that will wrap";
ProductList.price=19.99;
ProductList.qty=2;
ProductList.next();


ProductList.id="ABC00011";
ProductList.bomType="SALES";
ProductList.description="test with longer description that will wrap";
ProductList.price=19.99;
ProductList.qty=2;
ProductList.next();


ProductList.id="ABC00012";
ProductList.bomType="SALES";
ProductList.description="test with longer description that will wrap";
ProductList.price=19.99;
ProductList.qty=2;
ProductList.next();


ProductList.id="ABC00013";
ProductList.bomType="SALES";
ProductList.description="test with longer description that will wrap";
ProductList.price=19.99;
ProductList.qty=2;
ProductList.next();


ProductList.id="ABC00014";
ProductList.bomType="SALES";
ProductList.description="test with longer description that will wrap";
ProductList.price=19.99;
ProductList.qty=2;
ProductList.next();


ProductList.id="ABC00015";
ProductList.bomType="SALES";
ProductList.description="test with longer description that will wrap";
ProductList.price=19.99;
ProductList.qty=2;
ProductList.next();


ProductList.id="ABC00016";
ProductList.bomType="SALES";
ProductList.description="test with longer description that will wrap";
ProductList.price=19.99;
ProductList.qty=2;
ProductList.next();


ProductList.id="ABC00017";
ProductList.bomType="SALES";
ProductList.description="test with longer description that will wrap";
ProductList.price=19.99;
ProductList.qty=2;
ProductList.next();


ProductList.id="ABC00018";
ProductList.bomType="SALES";
ProductList.description="test with longer description that will wrap";
ProductList.price=19.99;
ProductList.qty=2;
ProductList.next();

ProductList.id="ABC00019";
ProductList.bomType="SALES";
ProductList.description="test with longer description that will wrap";
ProductList.price=19.99;
ProductList.qty=2;
ProductList.next();


ProductList.id="ABC00020";
ProductList.bomType="SALES";
ProductList.description="test with longer description that will wrap";
ProductList.price=19.99;
ProductList.qty=2;
ProductList.next();

ProductList.id="ABC00021";
ProductList.bomType="SALES";
ProductList.description="test with longer description that will wrap";
ProductList.price=19.99;
ProductList.qty=2;
ProductList.next();

ProductList.id="ABC00022";
ProductList.bomType="SALES";
ProductList.description="test with longer description that will wrap";
ProductList.price=19.99;
ProductList.qty=2;
ProductList.next();

ProductList.id="ABC00023";
ProductList.bomType="SALES";
ProductList.description="test with longer description that will wrap";
ProductList.price=19.99;
ProductList.qty=2;
ProductList.next();

ProductList.id="ABC00024";
ProductList.bomType="SALES";
ProductList.description="test with longer description that will wrap";
ProductList.price=19.99;
ProductList.qty=2;
ProductList.next();

ProductList.id="ABC00025";
ProductList.bomType="SALES";
ProductList.description="test with longer description that will wrap";
ProductList.price=19.99;
ProductList.qty=2;
ProductList.next();

ProductList.id="ABC00026";
ProductList.bomType="SALES";
ProductList.description="test with longer description that will wrap";
ProductList.price=19.99;
ProductList.qty=2;
ProductList.next();

ProductList.id="ABC00027";
ProductList.bomType="SALES";
ProductList.description="test with longer description that will wrap";
ProductList.price=19.99;
ProductList.qty=2;
ProductList.next();

ProductList.id="ABC00028";
ProductList.bomType="SALES";
ProductList.description="test with longer description that will wrap";
ProductList.price=19.99;
ProductList.qty=2;
ProductList.next();

ProductList.id="ABC00029";
ProductList.bomType="SALES";
ProductList.description="test with longer description that will wrap";
ProductList.price=19.99;
ProductList.qty=2;
ProductList.next();

ProductList.id="ABC00030";
ProductList.bomType="SALES";
ProductList.description="test with longer description that will wrap";
ProductList.price=19.99;
ProductList.qty=2;
ProductList.next();


return ProductList;