if (cfg.editions == "Digital"){
    return 6;
}
if (cfg.editions == "Base"){
    return 10;
}
if (cfg.editions == "Professional"){
    return 25;
}
if (cfg.editions == "Enterprise"){
    return 125;
}
if (cfg.editions == "Enterprise Plus"){
    return 4000;
}
return 0;