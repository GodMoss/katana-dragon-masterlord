var mapping={"Pro Edition - 2 Connections":2,"Pro Edition - 3 Connections":3,"Pro Edition - 4 Connections":4,"Professional Edition":5,"Pro Plus Edition":7,"Enterprise Edition":10,"Enterprise Plus Edition":15};

return mapping[cfg.integrationLicense];