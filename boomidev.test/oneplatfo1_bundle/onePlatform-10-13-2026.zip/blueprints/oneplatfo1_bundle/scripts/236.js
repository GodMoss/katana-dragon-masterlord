var productListLength=ProductList.length;
if(productListLength == 0){
  return ProductList;
}

var maxOrderNumber = ProductList.sort((a, b) => {return b.orderNumber - a.orderNumber;});

var maxOrder=maxOrderNumber.find((y) => {return y.orderNumber>0;});

ProductList.forEach(p => {
  var bomType = p.bomType.toLowerCase();
  if (bomType != "spec") {
    p.type = "COMPONENT";
  }
  if(["AI-MCT-A01","AI-MCT-A05","AI-MCT-A50"].includes(p.id)){
    p.quantity=p.quantity*cfg.additionalMessagesAddOnQuantity;
  }
  if(["INT-STD-TEST-CON","INT-STD-PROD-CON","INT-ENT-TEST-CON","INT-ENT-PROD-CON"].includes(p.id)){
    p.uniqueIdentifier=p.id;
  }
  if(["INT-STD-TEST-CON-ADD","INT-STD-PROD-CON-ADD","INT-ENT-TEST-CON-ADD","INT-ENT-PROD-CON-ADD"].includes(p.id)){
    var idSplit=p.id.split("-").pop();
    p.parentProduct=idSplit.join("-");

  }
  if(p.notes!=null){
    if(p.notes=="Customer Care" && p.notes!=null){
      p.orderNumber=maxOrder.orderNumber+1;
    }
  }
  if(p.id=="AI-MCT"){
    p.price=cfg.messageTierPrice;
    p.annual_recurring_price.value=cfg.messageTierPrice;
  }
});


for(x of ProductList){
  x.name=x.description;
  x.extended["productCode"]=x.id;
  x.extended["cbom.line.custom.extendedExampleTest"]="CBOM CUSTOM TEST";
  x.extended["extendedExampleTest"]="CBOM CUSTOM TEST";
}
        
        return ProductList;