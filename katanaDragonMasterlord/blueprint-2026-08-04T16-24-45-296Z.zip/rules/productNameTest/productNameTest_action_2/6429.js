ProductList.id = "MDDCU_40MDDCU";
    ProductList.bomType = "Sales";
    ProductList.uniqueIdentifier = "MDDCU_Sales";
    ProductList.qty = 1;
   ProductList.extended = {
            "QuoteID" : partner.quote.id
        };
    ProductList.next();
return ProductList;