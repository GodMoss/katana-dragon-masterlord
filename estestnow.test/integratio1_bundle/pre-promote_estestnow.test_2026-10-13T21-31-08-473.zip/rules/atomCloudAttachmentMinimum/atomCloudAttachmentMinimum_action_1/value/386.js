if(cfg.integrationLicense=="Enterprise Edition" || cfg.integrationLicense=="Enterprise Plus Edition"){
    return 2;
}
return 1;