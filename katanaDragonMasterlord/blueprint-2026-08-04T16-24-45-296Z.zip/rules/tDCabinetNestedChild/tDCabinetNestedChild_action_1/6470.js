ProductList.uniqueIdentifier = "TD Cabinet Parent";
ProductList.id = "TD_PARENT_1";
//ProductList.parentProduct = "TD Cabinet Parent";
ProductList.qty = 1;
ProductList.bomType = "SALES";
ProductList.price = 100;
ProductList.next();

ProductList.uniqueIdentifier = "Child 1";
ProductList.id = "CJILD_SAMPLE_1";
ProductList.parentProduct = "TD Cabinet Parent";
ProductList.qty = 1;
ProductList.bomType = "SALES";
ProductList.price = 100;
ProductList.next();

ProductList.uniqueIdentifier = "child 2";
ProductList.id = "CHILD_SAMPLE_2";
ProductList.parentProduct = "Child 1";
ProductList.qty = 1;
ProductList.bomType = "SALES";
ProductList.price = 100;
ProductList.next();
return ProductList;