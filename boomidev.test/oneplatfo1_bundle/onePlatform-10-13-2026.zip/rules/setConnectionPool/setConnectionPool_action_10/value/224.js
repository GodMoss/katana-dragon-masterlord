if (cfg.editions == "Digital"){
return 1;
}
if (cfg.editions == "Base"){
return 1;
}
if (cfg.editions == "Professional"){
return 2;
}
if (cfg.editions == "Enterprise"){
return 2;
}
if (cfg.editions == "Enterprise Plus"){
return 2;
}
return 0;