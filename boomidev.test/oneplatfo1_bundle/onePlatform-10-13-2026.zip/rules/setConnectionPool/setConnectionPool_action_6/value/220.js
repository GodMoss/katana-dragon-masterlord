if (cfg.editions == "Enterprise Plus"){
    return 1000;
}
return 0;