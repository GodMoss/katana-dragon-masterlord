ProductList.id="TEST CHILD1";
ProductList.quantity=1;
ProductList.parentProduct="F19E0A8245D0C559440FEA6BE6D80972";
ProductList.uniqueIdentifier="TEST CHILD1";
ProductList.orderNumber=1;

return ProductList;