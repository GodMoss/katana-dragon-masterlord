ProductList.id="TEST CHILD2";
ProductList.quantity=1;
ProductList.parentProduct="F19E0A8245D0C559440FEA6BE6D80972";
ProductList.uniqueIdentifier="TEST CHILD2";
ProductList.orderNumber=2;

return ProductList;