if((cfg.integrationLicense=="Enterprise Edition" || cfg.integrationLicense=="Enterprise Plus Edition") && cfg.atomCloudAttachment<2){
    return true;
}
else if(cfg.atomCloudAttachment<1){
    return true;
}
return false;