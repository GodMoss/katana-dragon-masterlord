ProductList.id = "Dummy";
    ProductList.qty = 1;
    ProductList.orderNumber = 1;
    ProductList.bomType = "dummy";
	ProductList.description = "Dummy";
	ProductList.uniqueIdentifier = "Dummy";
	ProductList.next();

return ProductList;