if(["Tier 1","Tier 2","Tier 3","Tier 4"].includes(cfg.platformMessageTier)){
    return "";
}
else if(["Tier 5","Tier 6","Tier 7"].includes(cfg.platformMessageTier)){
    return "AI-MCT-A01";
}
else if(["Tier 8","Tier 9","Tier 10","Tier 11"].includes(cfg.platformMessageTier)){
    return "AI-MCT-A05";
}
return "AI-MCT-A50";