ProductList.id="MFT-BDL";
ProductList.quantity=1;
ProductList.parentProduct="58FF7DB97DBD2B05B2692D111F83538D";
ProductList.uniqueIdentifier="MFT-BDL";
ProductList.description="MFT-BDL "+cfg.mFTTier;
ProductList.orderNumber=150;
ProductList.next();

ProductList.id="MFT-MTC";
ProductList.quantity=cfg.dataEgressCapacityLimit;
ProductList.parentProduct="MFT-BDL";
ProductList.description="MFT-MTC";
ProductList.orderNumber=151;
ProductList.next();

if(cfg.additionalStorage>0){
    ProductList.id="MFT-ADD-STOR-1TB";
    ProductList.quantity=cfg.additionalStorage;
    ProductList.parentProduct="MFT-BDL";
    ProductList.description="MFT-ADD-STOR-1TB";
    ProductList.orderNumber=152;
    ProductList.next();
}

if(cfg.mFTDedicatedCloudServices==true){
    ProductList.id="MFT-DCS";
    ProductList.quantity=1;
    ProductList.parentProduct="MFT-BDL";
    ProductList.description="MFT-DCS";
    ProductList.orderNumber=153;
    ProductList.next();
}


return ProductList;