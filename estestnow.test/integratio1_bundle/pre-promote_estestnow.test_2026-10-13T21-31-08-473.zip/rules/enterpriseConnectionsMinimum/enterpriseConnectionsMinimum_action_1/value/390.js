if(cfg.integrationLicense=="Enterprise Edition"){
    return 1;
}

return 2;