if (cfg.editions == "Digital"){
    return 2;
}
if (cfg.editions == "Base"){
    return 2;
}
if (cfg.editions == "Professional"){
    return 2;
}
if (cfg.editions == "Enterprise"){
    return 4;
}
if (cfg.editions == "Enterprise Plus"){
    return 4;
}
return 0;