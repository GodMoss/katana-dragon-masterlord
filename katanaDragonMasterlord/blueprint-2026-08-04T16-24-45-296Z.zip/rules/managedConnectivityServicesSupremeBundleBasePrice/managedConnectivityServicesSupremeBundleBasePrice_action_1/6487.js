ProductList.orderNumber = 10;
ProductList.id = 'Managed Connectivity Services Supreme Bundle';
ProductList.quantity = 1;
ProductList.price = 0;
ProductList.bomType = 'Sales';
ProductList.uniqueIdentifier = 'managedConnectivityServicesSupremeBundle';
ProductList.extended.sys_id = 'f2c92ac6a5260210f8774c9b4be6ce56';
ProductList.extended.productCode = 'MANAGEDCON1';
return ProductList;