if((cfg.integrationLicense=="Enterprise Edition" || cfg.integrationLicense=="Enterprise Plus Edition")){
    return "Quantity cannot be below 2";
}
else{
    return "Quantity cannot be below 1";
}