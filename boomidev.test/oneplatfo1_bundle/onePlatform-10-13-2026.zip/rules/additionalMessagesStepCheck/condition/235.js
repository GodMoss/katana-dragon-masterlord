if(cfg.additionalMessagesAddOn=="" || cfg.additionalMessagesAddOn==null || cfg.additionalMessagesAddOnQuantity==0){
  return false;
}
var tierMap={
  "Tier 1": 100000,
  "Tier 2": 250000,
  "Tier 3": 500000,
  "Tier 4": 1000000,
  "Tier 5": 2000000,
  "Tier 6": 5000000,
  "Tier 7": 10000000,
  "Tier 8": 25000000,
  "Tier 9": 50000000,
  "Tier 10": 100000000,
  "Tier 11": 250000000,
  "Tier 12": 500000000,
  "Tier 13": 1000000000,
  "Tier 14": 2000000000,
  "Tier 15": 3000000000,
  "Tier 16": 4000000000,
  "Tier 17": 5000000000,
  "Tier 18": 6000000000,
  "Tier 19": 7000000000,
  "Tier 20": 8000000000,
  "Tier 21": 9000000000,
  "Tier 22": 10000000000,
  "Tier 23": 11000000000,
  "Tier 24": 12000000000,
  "Tier 25": 13000000000,
  "Tier 26": 14000000000
};

var additionMessagesMap={
    "AI-MCT-A01": 1000000,
    "AI-MCT-A05": 5000000,
    "AI-MCT-A50": 50000000
};

var totalMessages=tierMap[cfg.platformMessageTier]+(additionMessagesMap[cfg.additionalMessagesAddOn]*cfg.additionalMessagesAddOnQuantity);

var tierNumber = cfg.platformMessageTier.substring(cfg.platformMessageTier.lastIndexOf(" ") + 1) * 1;

if(totalMessages>=tierMap["Tier "+(tierNumber+1)]){
    return true;
}


return false;