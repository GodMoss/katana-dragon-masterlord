ProductList.pricing = { "productSellingModelId": "TermDefined", "startDate": "2023/01/19", "testing": "hello"};
ProductList.pricing.pricingTerm = 100;
var x = "endDate";
ProductList.pricing[x] = "2123/01/19";
ProductList.pricing["pricingTermUnit"] = "Years";
ProductList.pricing.discount = 99;
ProductList.extended.discount = 99;
ProductList.id = "test";
ProductList.next();
ProductList.forEach( p => {
    p.pricing = {"productSellingModelId": "OneTime", "grogu": "hi"};
    p.pricing.han = "solo";
});
for (var t of ProductList) {
    t.pricing = {"productSellingModelId": "OneTime", "mando": "hi"};
    t.pricing.luke = "Test";
}
return ProductList;