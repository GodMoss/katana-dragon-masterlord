if(cfg.integrationLicense=="Enterprise Edition"){
    return "Quantity cannot be less than 2";
}

return "Quantity cannot be less than 4";