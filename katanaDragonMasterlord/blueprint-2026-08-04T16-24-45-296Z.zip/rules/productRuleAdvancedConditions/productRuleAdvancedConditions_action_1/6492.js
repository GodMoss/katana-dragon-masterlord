
/* Create a product where quantity is based on area, model name is the id, room length and room width are extended parameters and parent product is furniture size */

/*
ProductList.id = cfg.roomArea;
ProductList.qty = cfg.roomArea;
ProductList.price = 0;
ProductList.extendedParameters = {
  roomLength: cfg.roomLength,
  roomWidth: cfg.roomWidth
};
ProductList.parentProduct = cfg.furnitureSize;
ProductList.bomType = 'Area';
ProductList.type = 'Product';
ProductList.next();
return ProductList;*/
return ProductList;