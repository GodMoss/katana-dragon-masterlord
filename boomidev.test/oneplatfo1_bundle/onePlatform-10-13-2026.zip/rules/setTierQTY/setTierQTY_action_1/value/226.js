if (cfg.platformMessageTier == "Tier 1"){
return 100000;
}
if (cfg.platformMessageTier == "Tier 2"){
return 250000;
}
if (cfg.platformMessageTier == "Tier 3"){
return 500000;
}
if (cfg.platformMessageTier == "Tier 4"){
return 1000000;
}
if (cfg.platformMessageTier == "Tier 5"){
return 2000000;
}
if (cfg.platformMessageTier == "Tier 6"){
return 5000000;
}
if (cfg.platformMessageTier == "Tier 7"){
return 10000000;
}    
if (cfg.platformMessageTier == "Tier 8"){
return 25000000;
}
if (cfg.platformMessageTier == "Tier 9"){
return 50000000;
}
if (cfg.platformMessageTier == "Tier 10"){
return 100000000 ;
}    
if (cfg.platformMessageTier == "Tier 11"){
return 250000000 ;
}   
if (cfg.platformMessageTier == "Tier 12"){
return 500000000 ;
} 
if (cfg.platformMessageTier == "Tier 13"){
return 1000000000 ;
}
if (cfg.platformMessageTier == "Tier 14"){
return 2000000000 ;
}
if (cfg.platformMessageTier == "Tier 15"){
return 3000000000 ;
}
if (cfg.platformMessageTier == "Tier 16"){
return 4000000000 ;
}
if (cfg.platformMessageTier == "Tier 17"){
return 5000000000 ;
}       
if (cfg.platformMessageTier == "Tier 18"){
return 6000000000 ;
}       
if (cfg.platformMessageTier == "Tier 19"){
return 7000000000 ;
}       
if (cfg.platformMessageTier == "Tier 20"){
return 8000000000 ;
}       
if (cfg.platformMessageTier == "Tier 21"){
return 9000000000 ;
}     
if (cfg.platformMessageTier == "Tier 22"){
return 10000000000 ;
} 
if (cfg.platformMessageTier == "Tier 23"){
return 11000000000 ;
} 
if (cfg.platformMessageTier == "Tier 24"){
return 12000000000 ;
}
if (cfg.platformMessageTier == "Tier 25"){
return 13000000000 ;
}
if (cfg.platformMessageTier == "Tier 26"){
return 14000000000 ;
}
  
return 0;