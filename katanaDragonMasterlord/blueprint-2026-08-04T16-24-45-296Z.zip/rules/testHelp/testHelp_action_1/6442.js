//encodeURI("http://domain.com/?search=path to a document.pdf");
//encodeURIComponent("http://domain.com/?search=path to a document.pdf"); 
return ProductList;