if(ProductList.length == 0){
  return ProductList;
}

var license="";

ProductList.forEach(p => {
  var bomType = p.bomType.toLowerCase();
  if (bomType != "spec") {
    p.type = "COMPONENT";
  }
  if(p.parentProduct!=null && p.parentProduct=="8815DC942DADC0142DC0B49167BD66CE"){
    p.uniqueIdentifier=p.id;
    license=p.id;
  }
  if(p.parentProduct==null){
    p.parentProduct=license;
  }
});
        
return ProductList;
        