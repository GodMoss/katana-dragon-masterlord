var tierMapping={"Tier 1":1.5, "Tier 2":3, "Tier 3":6, "Tier 4":10, "Tier 5":18, "Tier 6":35, "Tier 7":99};

return tierMapping[cfg.mFTTier];