if((cfg.publicCloudServiceTest+cfg.publicCloudServiceProduction)>cfg.publicCloudServicePool){
    return true;
}
return false;