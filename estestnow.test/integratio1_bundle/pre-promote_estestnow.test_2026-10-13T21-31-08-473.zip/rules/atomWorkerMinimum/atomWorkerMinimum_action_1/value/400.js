if(cfg.integrationLicense=="Pro Plus Edition"){
    return 1;
}
return 2;