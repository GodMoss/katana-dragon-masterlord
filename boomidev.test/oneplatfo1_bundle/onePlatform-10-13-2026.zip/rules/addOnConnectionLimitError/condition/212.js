if((cfg.addonEnterpriseProductionConnection+cfg.addonEnterpriseTestConnection+cfg.addonStandardProductionConnection+cfg.addonStandardTestConnection)>600){
    return true;
}
return false;