ProductList.id="ABC";
ProductList.quantity=2;
ProductList.bomType="SALES"; 
return ProductList;