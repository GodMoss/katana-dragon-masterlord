if((cfg.integrationLicense=="Enterprise Edition" || cfg.integrationLicense=="Enterprise Plus Edition") && cfg.atomCloudAttachmentTest<2){
    return true;
}
else if(cfg.atomCloudAttachmentTest<1){
    return true;
}
return false;