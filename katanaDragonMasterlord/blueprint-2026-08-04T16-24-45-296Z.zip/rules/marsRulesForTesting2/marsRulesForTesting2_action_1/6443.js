ProductList.id = "MarsParentProduct1";
ProductList.qty = 15;
ProductList.uniqueIdentifier = "MarsParentProduct1";
return ProductList;