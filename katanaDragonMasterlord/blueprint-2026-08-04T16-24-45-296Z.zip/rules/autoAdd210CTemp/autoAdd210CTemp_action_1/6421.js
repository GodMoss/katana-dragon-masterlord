ProductList.id = "UCSX-210C-M7-U";    
ProductList.bomType = "manufacturing";    

ProductList.qty=1;    
ProductList.next();
return ProductList;