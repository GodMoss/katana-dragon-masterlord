var tierMapping={"Tier 1":1.5, "Tier 2":3, "Tier 3":6, "Tier 4":10, "Tier 5":18, "Tier 6":35, "Tier 7":99};
var tierAbove=(cfg.mFTTier.substring(cfg.mFTTier.length-(1*1)))*1 +1;


if(tierMapping[cfg.mFTTier]+cfg.additionalStorage>=tierMapping["Tier "+tierAbove]){
    return true;
}

return false;